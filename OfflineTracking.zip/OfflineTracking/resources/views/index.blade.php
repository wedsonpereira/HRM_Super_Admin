@extends('offlinetracking::layouts.master')

@section('content')
    <h1>Hello World</h1>

    <p>Module: {!! config('offlinetracking.name') !!}</p>
@endsection
